# Aroma & Co. — online payments (Stripe test mode)

1. Create a free account at https://dashboard.stripe.com (no business needed for test mode). Turn on "Test mode"/Sandbox.
2. Developers -> API keys -> copy the *Secret key* (sk_test_...).
3. Deploy this folder to Netlify from a GitHub repo (drag-and-drop does NOT deploy functions).
   Site settings -> Environment variables -> add STRIPE_SECRET_KEY = sk_test_...
   Then redeploy.
4. Local test: `npm i -g netlify-cli`, then in this folder:
   `STRIPE_SECRET_KEY=sk_test_... netlify dev`  -> http://localhost:8888
5. Pay with test card 4242 4242 4242 4242, any future date, any CVC.
   The payment shows up in Stripe Dashboard -> Payments, with name/phone/address in metadata.

Notes: UAH is shown on the site but charged in EUR (Stripe doesn't support UAH).
Keep prices/rates in netlify/functions/create-checkout.js in sync with index.html.
